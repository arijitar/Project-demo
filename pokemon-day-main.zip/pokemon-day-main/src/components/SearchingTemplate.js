function SearchingTemplate(){
    return(
        <div className = 'flex justify-center'>
            <img height = "300px" width = "350px" src="/searching.gif" alt = 'searching' />
        </div> 
    );
}

export default SearchingTemplate;